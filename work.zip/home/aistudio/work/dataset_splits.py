# 训练数据
import pandas as pd
import os
from tqdm import tqdm

random_seed = 2021

Image_path = 'Train/fundus_image'                             # 数据存放相对路径
total_data = pd.read_excel('PaddleClas/dataset/常规赛：PALM病理性近视预测/Train/Classification.xlsx')       # 数据xlsx文件

for i in range(len(total_data)):                                                         # 将DataFrame表格中的图片补足路径
    total_data.iloc[i, 0] = os.path.join(Image_path, total_data.iloc[i, 0])              # 拼接路径

total_data = total_data.sample(frac=1.0, random_state=random_seed).reset_index(drop=True)       # frac=1.0对应随机采样全部样本（表格数据），对应打乱表格


train_percent = 0.75

train_data = total_data.to_numpy()[:int(len(total_data) * train_percent)]                # 要保存的训练数据
eval_data = total_data.to_numpy()[int(len(total_data) * train_percent):]                 # 要保存的验证数据

train_txt_save_path = 'PaddleClas/dataset/常规赛：PALM病理性近视预测/train_list.txt'
val_txt_save_path = 'PaddleClas/dataset/常规赛：PALM病理性近视预测/val_list.txt'

with open(train_txt_save_path, 'w') as f:
    t_tq = tqdm(train_data)
    t_tq.set_description('Train Data Spliting')
    for i in t_tq:
        f.write(i[0]+' '+str(i[1])+'\n')

with open(val_txt_save_path, 'w') as f:
    v_tq = tqdm(eval_data)
    v_tq.set_description('Val Data Spliting')
    for i in v_tq:
        f.write(i[0]+' '+str(i[1])+'\n')